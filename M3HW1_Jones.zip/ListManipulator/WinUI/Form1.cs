﻿/**
* 9/30/2022
* CSC 253
* Kent Jones Jr
* This program will allow the user to manipulate a list of integers from a text file.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ListManipulatorLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Reading random.txt into list
            List<int> randomNumsList = new List<int>();
            StreamReader numFile = File.OpenText("random.txt");
            while (!numFile.EndOfStream)
            {
                randomNumsList.Add(int.Parse(numFile.ReadLine()));
            }
            numFile.Close();

            // Remove all the elements containing a negative value.
            randomNumsList.RemoveAll(x => x < 0);

            //Find all numbers between 1 through 10.
            List<int> randomNumsList2 = randomNumsList.FindAll(n => n >= 1 && n < 10);
            
            //Displaying list 
            foreach (var num in randomNumsList2)
            {
                numberListBox.Items.Add(num);
            }
        }
    }
}
