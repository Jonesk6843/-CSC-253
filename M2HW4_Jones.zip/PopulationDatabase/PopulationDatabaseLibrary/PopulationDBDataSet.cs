﻿namespace PopulationDatabaseLibrary
{


    partial class PopulationDBDataSet
    {
    }
}

namespace PopulationDatabaseLibrary.PopulationDBDataSetTableAdapters {
    
    
    public partial class CityTableAdapter {
    }
}
