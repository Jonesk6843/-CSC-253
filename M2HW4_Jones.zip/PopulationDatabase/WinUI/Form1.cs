﻿/**
* 9/22/2022
* CSC 253
* Kent Jones JR
* This program will allow the user to filter through the Population database and get certain information such as max population, averages, etc.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PopulationDatabaseLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void cityBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.cityBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.populationDBDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'populationDBDataSet.City' table. You can move, or remove it, as needed.
            this.cityTableAdapter.Fill(this.populationDBDataSet.City);

        }

        private void cityButton_Click(object sender, EventArgs e)
        {
            //Sorts the database by cityname ascending
            this.cityTableAdapter.FillByCity(this.populationDBDataSet.City);
        }

        private void popAscendButton_Click(object sender, EventArgs e)
        {
            //Sorts the database by population ascending
            this.cityTableAdapter.FillByPopulationASC(this.populationDBDataSet.City);
        }

        private void popDescendButton_Click(object sender, EventArgs e)
        {
            //Sorts the database by population descending
            this.cityTableAdapter.FillByPopulationDESC(this.populationDBDataSet.City);
        }

        private void popTotalButton_Click(object sender, EventArgs e)
        {
            //declare variables
            double sumPopulation;

            //Set variable to sum queary
            sumPopulation = (double) this.cityTableAdapter.SumPopulation();

            //display sum
            MessageBox.Show("The total population of all the cities is: " + sumPopulation.ToString());
        }

        private void popAverageButton_Click(object sender, EventArgs e)
        {
            //declare variables
            decimal averagePopulation;
            
            //set variable to average queary
            averagePopulation = (decimal) this.cityTableAdapter.AveragePopulation();
            
            //display average
            MessageBox.Show("The average population of all the cities is: " + averagePopulation.ToString());
        }

        private void highPopButton_Click(object sender, EventArgs e)
        {
            //declare variables
            string cityMax;
            decimal highPopulation;

            //set variables to cityMax and maxPopulation quearies
            cityMax = (string)this.cityTableAdapter.cityMax();
            highPopulation = (decimal) this.cityTableAdapter.MaxPopulation();

            //Display highest city and its population
            MessageBox.Show("The highest population of all the cities is " + cityMax + " with over "+ highPopulation.ToString() + " people.");
        }

        private void lowPopButton_Click(object sender, EventArgs e)
        {
            //declare variables
            string cityMin;
            decimal lowPopulation;

            //set variables to cityMin and minPopulation queries
            cityMin = (string) this.cityTableAdapter.cityMin();
            lowPopulation = (decimal) this.cityTableAdapter.MinPopulation();

            //Display lowest city and its population
            MessageBox.Show("The lowest population of all the cities is " + cityMin + " with " + lowPopulation.ToString() + " people.");
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.Fill(this.populationDBDataSet.City);
        }
    }
}
