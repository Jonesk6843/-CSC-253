﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TuitionIncreaseLibrary
{
    public class tuitionCalculations
    {
        public static double tuitionFormula(double tuitionValue)
        {
            //Declare variables
            double tuitionTotal;
            double tuitionPercent;

            // calculate percentage
            tuitionPercent = tuitionValue * 0.02;

            //add percentage value
            tuitionTotal = tuitionValue + tuitionPercent;

            //return calculation
            return tuitionTotal;
        }
    }
}
