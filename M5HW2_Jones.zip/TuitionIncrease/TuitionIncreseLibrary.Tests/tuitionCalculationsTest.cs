﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TuitionIncreaseLibrary;
using Xunit;

namespace TuitionIncreseLibrary.Tests
{
    public class tuitionCalculationsTest
    {
        public class tuitionCalculationsTests
        {
            [Fact]
            public void tuitionFormula_ShouldCalculateTuition()
            {
                // Arrange
                double expect = 6120; 

                // Act
                double actual = tuitionCalculations.tuitionFormula(6000);

                //Assert
                Assert.Equal(expect, actual);
            }
        
        }
    }
}
