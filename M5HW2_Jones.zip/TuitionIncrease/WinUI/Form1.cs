﻿/**
* 11/14/2022
* CSC 253
* Kent Jones Jr
* This program will display to the user the 2% increase of their tuition.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TuitionIncreaseLibrary;
namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Create public List to store number totals
        public List <double> numList = new List<double>();
        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                //Declare Variables
                double tuition = 6000;
                int year = 1;

                //Loop tuiton amount up to 5 years
                while (year <= 5)
                {
                    tuition = tuitionCalculations.tuitionFormula(tuition);
                    tuitionListBox.Items.Add($"Tuition for year {year} is: ${Math.Round(tuition, 2)}");
                    numList.Add(tuition); //Tuition values to be checked
                    year++;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}