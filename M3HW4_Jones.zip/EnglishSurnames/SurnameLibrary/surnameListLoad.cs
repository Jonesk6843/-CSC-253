﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SurnameLibrary
{
    public static class surnameListLoad
    {
        public static List<string> surnames = new List<string>();
    }
}
