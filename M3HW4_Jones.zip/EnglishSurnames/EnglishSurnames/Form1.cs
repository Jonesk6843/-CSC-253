﻿/**
* 10/8/2022
* CSC 253
* Kent Jones Jr
* This program will allow the user to sort through a list of surnames.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SurnameLibrary;

namespace EnglishSurnames
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            //Reading surnames.txt into list
            StreamReader nameFile = File.OpenText("surnames.txt");
            while (!nameFile.EndOfStream)
            {
                surnameListLoad.surnames.Add(nameFile.ReadLine());
            }
            nameFile.Close();

            //Display surnames
            foreach (var surname in surnameListLoad.surnames)
            {
                surnameListBox.Items.Add(surname);
            }

        }
        private void longNamButton_Click(object sender, EventArgs e)
        {
            //Declare variable and set textbox
            int maxLength;
            maxLength = int.Parse(longNameTextBox.Text);

            //clear list
            surnameListBox.Items.Clear();

            //Find all names that are longer than the input value
            List<string> longest = surnameListLoad.surnames.FindAll(n => n.Length >= maxLength);

            //Displaying long name list
            foreach (var surname in longest)
            {
                surnameListBox.Items.Add(surname);
            }
        }

        private void shortNamButton_Click(object sender, EventArgs e)
        {
            //Declare variable and set textbox
            int minLength;
            minLength = int.Parse(shortNameTextBox.Text);

            //clear list
            surnameListBox.Items.Clear();

            //Find all names that are shorter than the input value
            List<string> shortest = surnameListLoad.surnames.FindAll(n => n.Length <= minLength);

            //Displaying list 
            foreach (var surname in shortest)
            {
                surnameListBox.Items.Add(surname);
            }
        }

        private void beginNameButton_Click(object sender, EventArgs e)
        {
            //Declare variable and set textbox
            string beginName;
            beginName = beginNameTextBox.Text;

            //clear list
            surnameListBox.Items.Clear();            

            //Find all names that begin with input
            List <string> nameFragements = surnameListLoad.surnames.FindAll(n => n.Contains(beginName));

            //Displaying list 
            foreach (var fragment in nameFragements)
            {
                surnameListBox.Items.Add(fragment);
            }
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            string nameSearch;
            //clear list
            surnameListBox.Items.Clear();

            //add text box variable
            nameSearch = searchTextBox.Text;

            //Find all names that math input
            List <string> names = surnameListLoad.surnames.FindAll(n => n == nameSearch );

            //Displaying list 
            foreach (var name in names)
            {
                surnameListBox.Items.Add(name);
            }
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            //Display surnames
            foreach (var surname in surnameListLoad.surnames)
            {
                surnameListBox.Items.Add(surname);
            }
        }
    }
}
