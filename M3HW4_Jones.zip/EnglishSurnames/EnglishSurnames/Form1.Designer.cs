﻿namespace EnglishSurnames
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.surnameListBox = new System.Windows.Forms.ListBox();
            this.shortNamButton = new System.Windows.Forms.Button();
            this.beginNameButton = new System.Windows.Forms.Button();
            this.longNamButton = new System.Windows.Forms.Button();
            this.searchButton = new System.Windows.Forms.Button();
            this.longNameTextBox = new System.Windows.Forms.TextBox();
            this.shortNameTextBox = new System.Windows.Forms.TextBox();
            this.beginNameTextBox = new System.Windows.Forms.TextBox();
            this.searchTextBox = new System.Windows.Forms.TextBox();
            this.resetButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // surnameListBox
            // 
            this.surnameListBox.FormattingEnabled = true;
            this.surnameListBox.ItemHeight = 16;
            this.surnameListBox.Location = new System.Drawing.Point(12, 12);
            this.surnameListBox.Name = "surnameListBox";
            this.surnameListBox.Size = new System.Drawing.Size(224, 244);
            this.surnameListBox.TabIndex = 0;
            // 
            // shortNamButton
            // 
            this.shortNamButton.Location = new System.Drawing.Point(251, 103);
            this.shortNamButton.Name = "shortNamButton";
            this.shortNamButton.Size = new System.Drawing.Size(143, 23);
            this.shortNamButton.TabIndex = 1;
            this.shortNamButton.Text = "Names shorter than";
            this.shortNamButton.UseVisualStyleBackColor = true;
            this.shortNamButton.Click += new System.EventHandler(this.shortNamButton_Click);
            // 
            // beginNameButton
            // 
            this.beginNameButton.Location = new System.Drawing.Point(251, 146);
            this.beginNameButton.Name = "beginNameButton";
            this.beginNameButton.Size = new System.Drawing.Size(152, 23);
            this.beginNameButton.TabIndex = 2;
            this.beginNameButton.Text = "Name that begins with";
            this.beginNameButton.UseVisualStyleBackColor = true;
            this.beginNameButton.Click += new System.EventHandler(this.beginNameButton_Click);
            // 
            // longNamButton
            // 
            this.longNamButton.Location = new System.Drawing.Point(251, 55);
            this.longNamButton.Name = "longNamButton";
            this.longNamButton.Size = new System.Drawing.Size(143, 23);
            this.longNamButton.TabIndex = 3;
            this.longNamButton.Text = "Names longer than";
            this.longNamButton.UseVisualStyleBackColor = true;
            this.longNamButton.Click += new System.EventHandler(this.longNamButton_Click);
            // 
            // searchButton
            // 
            this.searchButton.Location = new System.Drawing.Point(251, 190);
            this.searchButton.Name = "searchButton";
            this.searchButton.Size = new System.Drawing.Size(113, 23);
            this.searchButton.TabIndex = 4;
            this.searchButton.Text = "Search Name";
            this.searchButton.UseVisualStyleBackColor = true;
            this.searchButton.Click += new System.EventHandler(this.searchButton_Click);
            // 
            // longNameTextBox
            // 
            this.longNameTextBox.Location = new System.Drawing.Point(411, 56);
            this.longNameTextBox.Name = "longNameTextBox";
            this.longNameTextBox.Size = new System.Drawing.Size(100, 22);
            this.longNameTextBox.TabIndex = 5;
            // 
            // shortNameTextBox
            // 
            this.shortNameTextBox.Location = new System.Drawing.Point(411, 103);
            this.shortNameTextBox.Name = "shortNameTextBox";
            this.shortNameTextBox.Size = new System.Drawing.Size(100, 22);
            this.shortNameTextBox.TabIndex = 6;
            // 
            // beginNameTextBox
            // 
            this.beginNameTextBox.Location = new System.Drawing.Point(411, 146);
            this.beginNameTextBox.Name = "beginNameTextBox";
            this.beginNameTextBox.Size = new System.Drawing.Size(100, 22);
            this.beginNameTextBox.TabIndex = 7;
            // 
            // searchTextBox
            // 
            this.searchTextBox.Location = new System.Drawing.Point(370, 191);
            this.searchTextBox.Name = "searchTextBox";
            this.searchTextBox.Size = new System.Drawing.Size(100, 22);
            this.searchTextBox.TabIndex = 8;
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(325, 233);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(113, 23);
            this.resetButton.TabIndex = 9;
            this.resetButton.Text = "Reset List";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(523, 260);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.searchTextBox);
            this.Controls.Add(this.beginNameTextBox);
            this.Controls.Add(this.shortNameTextBox);
            this.Controls.Add(this.longNameTextBox);
            this.Controls.Add(this.searchButton);
            this.Controls.Add(this.longNamButton);
            this.Controls.Add(this.beginNameButton);
            this.Controls.Add(this.shortNamButton);
            this.Controls.Add(this.surnameListBox);
            this.Name = "Form1";
            this.Text = "English Surname";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox surnameListBox;
        private System.Windows.Forms.Button shortNamButton;
        private System.Windows.Forms.Button beginNameButton;
        private System.Windows.Forms.Button longNamButton;
        private System.Windows.Forms.Button searchButton;
        private System.Windows.Forms.TextBox longNameTextBox;
        private System.Windows.Forms.TextBox shortNameTextBox;
        private System.Windows.Forms.TextBox beginNameTextBox;
        private System.Windows.Forms.TextBox searchTextBox;
        private System.Windows.Forms.Button resetButton;
    }
}

