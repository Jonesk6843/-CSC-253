﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace textFileAnalysisLibrary
{
    public class uniqueWordLists
    {
        public static List<string> uniqueList1 = new List<string>();
        public static List<string> uniqueList2 = new List<string>();
    }
}
