﻿/**
* 10/23/2022
* CSC 253
* Kent Jones Jr
* This Program will allow the user to sort throgh two list of words and compare and contrast the two.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using textFileAnalysisLibrary;
namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Populating uniqueListBox1
            StreamReader wordFile = File.OpenText("uniqueWord1.txt");
            while (!wordFile.EndOfStream)
            {
                //Tokenizing through the list of words
                string line = wordFile.ReadLine();
                string[] tokens = line.Split(',');
                for (int i = 0; i < tokens.Length; i++)
                {
                    uniqueWordLists.uniqueList1.Add(tokens[i]);
                }
            }
            wordFile.Close();

            //Adding words into listbox
            foreach (var word in uniqueWordLists.uniqueList1)
            {
                uniqueListBox1.Items.Add(word);
            }

            //Ppopulating uniqueListBox2
            StreamReader wordFile2 = File.OpenText("uniqueWord2.txt");
            while (!wordFile2.EndOfStream)
            {
                //Tokenizing through the list of words
                string line = wordFile2.ReadLine();
                string[] tokens = line.Split(',');
                for (int i = 0; i < tokens.Length; i++)
                {
                    uniqueWordLists.uniqueList2.Add(tokens[i]);
                }
            }
            wordFile2.Close();

            foreach (var word in uniqueWordLists.uniqueList2)
            {
                uniqueListBox2.Items.Add(word);
            }
        }

        private void uniqueWordButton_Click(object sender, EventArgs e)
        {
            //Clearing Listboxes
            uniqueListBox1.Items.Clear();
            uniqueListBox2.Items.Clear();

            //Taking out duplicate words and sorting them for list one
            var uniqueWords1 = from w in uniqueWordLists.uniqueList1.Distinct()
                              orderby w
                              select w;
            foreach (var word in uniqueWords1)
            {
                uniqueListBox1.Items.Add(word);
            }
            //Taking out duplicate words and sorting them for list two
            var uniqueWords2 = from w in uniqueWordLists.uniqueList2.Distinct()
                              orderby w
                              select w;
            foreach (var word in uniqueWords2)
            {
                uniqueListBox2.Items.Add(word);
            }
        }

        private void similarWordButton_Click(object sender, EventArgs e)
        {
            //Finding similar words in both collections
            var similarWords = uniqueWordLists.uniqueList1.Intersect(uniqueWordLists.uniqueList2);

            //Displaying each similar word
            foreach (var word in similarWords)
            {
                MessageBox.Show("Both Lists have: " + word);
            }
                
        }

        private void uniqueList1Button_Click(object sender, EventArgs e)
        {
            //Finding words unique only in list 1
            var uniqueTo1 = uniqueWordLists.uniqueList1.Except(uniqueWordLists.uniqueList2);

            //Displaying each unique word
            foreach (var word in uniqueTo1)
            {
                MessageBox.Show($"List1 have unique word {word} . List 2 does not.");
            }
        }

        private void uniqueList2Button_Click(object sender, EventArgs e)
        {
            //Finding words unique only in list 2
            var uniqueTo2 = uniqueWordLists.uniqueList2.Except(uniqueWordLists.uniqueList1);

            //Displaying each unique word
            foreach (var word in uniqueTo2)
            {
                MessageBox.Show($"List1 has unique word {word}. List 2 does not.");
            }
        }
    }
}
