﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uniqueListBox1 = new System.Windows.Forms.ListBox();
            this.uniqueListBox2 = new System.Windows.Forms.ListBox();
            this.uniqueWordButton = new System.Windows.Forms.Button();
            this.similarWordButton = new System.Windows.Forms.Button();
            this.uniqueList1Button = new System.Windows.Forms.Button();
            this.uniqueList2Button = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // uniqueListBox1
            // 
            this.uniqueListBox1.FormattingEnabled = true;
            this.uniqueListBox1.ItemHeight = 16;
            this.uniqueListBox1.Location = new System.Drawing.Point(12, 12);
            this.uniqueListBox1.Name = "uniqueListBox1";
            this.uniqueListBox1.Size = new System.Drawing.Size(206, 228);
            this.uniqueListBox1.TabIndex = 1;
            // 
            // uniqueListBox2
            // 
            this.uniqueListBox2.FormattingEnabled = true;
            this.uniqueListBox2.ItemHeight = 16;
            this.uniqueListBox2.Location = new System.Drawing.Point(408, 12);
            this.uniqueListBox2.Name = "uniqueListBox2";
            this.uniqueListBox2.Size = new System.Drawing.Size(206, 228);
            this.uniqueListBox2.TabIndex = 2;
            // 
            // uniqueWordButton
            // 
            this.uniqueWordButton.Location = new System.Drawing.Point(230, 35);
            this.uniqueWordButton.Name = "uniqueWordButton";
            this.uniqueWordButton.Size = new System.Drawing.Size(172, 23);
            this.uniqueWordButton.TabIndex = 3;
            this.uniqueWordButton.Text = "Display Unique Words";
            this.uniqueWordButton.UseVisualStyleBackColor = true;
            this.uniqueWordButton.Click += new System.EventHandler(this.uniqueWordButton_Click);
            // 
            // similarWordButton
            // 
            this.similarWordButton.Location = new System.Drawing.Point(230, 83);
            this.similarWordButton.Name = "similarWordButton";
            this.similarWordButton.Size = new System.Drawing.Size(172, 23);
            this.similarWordButton.TabIndex = 4;
            this.similarWordButton.Text = "Display Similar Words";
            this.similarWordButton.UseVisualStyleBackColor = true;
            this.similarWordButton.Click += new System.EventHandler(this.similarWordButton_Click);
            // 
            // uniqueList1Button
            // 
            this.uniqueList1Button.Location = new System.Drawing.Point(6, 47);
            this.uniqueList1Button.Name = "uniqueList1Button";
            this.uniqueList1Button.Size = new System.Drawing.Size(75, 23);
            this.uniqueList1Button.TabIndex = 5;
            this.uniqueList1Button.Text = "List 1";
            this.uniqueList1Button.UseVisualStyleBackColor = true;
            this.uniqueList1Button.Click += new System.EventHandler(this.uniqueList1Button_Click);
            // 
            // uniqueList2Button
            // 
            this.uniqueList2Button.Location = new System.Drawing.Point(103, 47);
            this.uniqueList2Button.Name = "uniqueList2Button";
            this.uniqueList2Button.Size = new System.Drawing.Size(75, 23);
            this.uniqueList2Button.TabIndex = 6;
            this.uniqueList2Button.Text = "List 2";
            this.uniqueList2Button.UseVisualStyleBackColor = true;
            this.uniqueList2Button.Click += new System.EventHandler(this.uniqueList2Button_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.uniqueList1Button);
            this.groupBox1.Controls.Add(this.uniqueList2Button);
            this.groupBox1.Location = new System.Drawing.Point(224, 121);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(178, 75);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Unique Words only found in";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(624, 243);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.similarWordButton);
            this.Controls.Add(this.uniqueWordButton);
            this.Controls.Add(this.uniqueListBox2);
            this.Controls.Add(this.uniqueListBox1);
            this.Name = "Form1";
            this.Text = "Text File Analysis";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox uniqueListBox1;
        private System.Windows.Forms.ListBox uniqueListBox2;
        private System.Windows.Forms.Button uniqueWordButton;
        private System.Windows.Forms.Button similarWordButton;
        private System.Windows.Forms.Button uniqueList1Button;
        private System.Windows.Forms.Button uniqueList2Button;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}

