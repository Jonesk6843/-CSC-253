﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace productSearchLibrary
{
    public class DBSearch
    {
        //ProductNum Search
        public static IEnumerable<Product> WhereProductNum(string numSearch, productDBDataContext DB) =>
            from row in DB.Products
            where row.Product_Number.ToLower().Equals(numSearch)
            select row;

        //ProductDesc Search
        public static IEnumerable<Product> WhereProductDescription(string descriptSearch, productDBDataContext DB) =>
            from row in DB.Products
            where row.Description.ToLower().Contains(descriptSearch)
            select row;
    }
}
