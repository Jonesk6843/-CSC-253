﻿/**
* 10/30/22
* CSC 253
* Kent Jones
* This program will allow the user to manipulate and search through a products database
*/
using productSearchLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using productSearchLibrary;
namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'productDBDataSet.Product' table. You can move, or remove it, as needed.
            this.productTableAdapter.Fill(this.productDBDataSet.Product);
            //Create a data Context Object
            productDBDataContext db = new productDBDataContext();

        }

        private void numSearchButton_Click(object sender, EventArgs e)
        {
            //Setting Search to variable
            string numSearch = productNumSearchTextBox.Text.ToLower();

            //Create a data Context Object
            productDBDataContext DB = new productDBDataContext();
            var search = DBSearch.WhereProductNum(numSearch, DB);

            //Clear and load searches 
            searchListBox.Items.Clear();
            foreach (var row in search)
            {
                searchListBox.Items.Add(row.Product_Number + "/" + row.Description + "/" + row.Units_On_Hand + "/" + row.Price);
            }
        }

        private void descriptionSearchButton_Click(object sender, EventArgs e)
        {
            //Setting Search to variable
            string descriptSearch = descriptionSearchTextBox.Text.ToLower();

            //Create a data Context Object
            productDBDataContext DB = new productDBDataContext();
            var search = DBSearch.WhereProductNum(descriptSearch, DB);

            //Clear and load searches 
            searchListBox.Items.Clear();
            foreach (var row in search)
            {
                searchListBox.Items.Add(row.Product_Number + "/" + row.Description + "/" +  row.Units_On_Hand + "/" + row.Price);
            }
        }
    }
}
