﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.CompilerServices;

namespace uniqueWordsClassLibrary
{
    public class uniqueWordList
    {
        //Temporary List for words
        public static List<string> uniqueList = new List<string>();
    }
}
