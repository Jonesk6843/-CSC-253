﻿/**
* 10/22/2022
* CSC 253
* Kent Jones Jr
* This program will allow the user to sort through a list of words.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using uniqueWordsClassLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private void uniqueButton_Click(object sender, EventArgs e)
        {
            //Reading textFile
            StreamReader wordFile = File.OpenText("UniqueWord.txt");
            while (!wordFile.EndOfStream)
            {
                //Tokenizing through the list of words
                string line = wordFile.ReadLine();
                string[] tokens = line.Split(',');
                for (int i = 0; i < tokens.Length; i++)
                {
                    uniqueWordList.uniqueList.Add(tokens[i]);
                }
            }
            wordFile.Close();

            //Taking out duplicate words and sorting them.
            var uniqueWords = from w in uniqueWordList.uniqueList.Distinct()
                          orderby w
                          select w;
            foreach (var word in uniqueWords)
            {
                uniqueWordListBox.Items.Add(word);
            }
        }
    }
}
