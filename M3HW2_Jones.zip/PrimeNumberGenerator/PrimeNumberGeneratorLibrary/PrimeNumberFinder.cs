﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;

namespace PrimeNumberGeneratorLibrary
{
    public class PrimeNumberFinder
    {
        public static List<int> primeNumbers(int num)
        {
            //Creating empty Prime list
            List<int> primeNums = new List<int>();

            //Pouplating List
            primeNums.FindAll(x => 2 <= num);

            //Finding Prime Nums
            List<int> primeNums2 = primeNums.FindAll(x => num % 2 ==0);
            //returning prime numbers
            return primeNums2;
        }
    }
}
