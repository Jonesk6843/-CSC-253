﻿/**
* 10/2/2022
* CSC 253
* Kent Jones Jr
* This program will allow users to generate any prime number greater than their inputted integer.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PrimeNumberGeneratorLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void enterButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Declare user variables
                int userNum;
                //Convert user input
                if (int.TryParse(userPrimeTextBox.Text, out userNum))
                {
                    foreach (var primeNumbers in PrimeNumberFinder.primeNumbers(userNum))
                    {
                        primeNumListBox.Items.Add(primeNumbers);
                    }
                }
                else
                {
                    MessageBox.Show("Please input valid numbers.", "Invalid Input");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
