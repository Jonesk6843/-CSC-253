﻿/**
* 11/26/2022
* CSC 253
* Kent Jones
* This program will allow the user to input and display their pet's name, type, and age.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PetClassLibrary;

namespace WPFUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //Creating instance of class
                Pet myPet = new Pet();

                //Get user input
                myPet.Name = nameTextBox.Text;
                myPet.Type = typeTextBox.Text;
                myPet.Age = int.Parse(ageTextBox.Text);

                //Display Info
                petInfoListBox.Items.Add("Pet's name: " + myPet.Name);
                petInfoListBox.Items.Add("Type of pet: " + myPet.Type);
                petInfoListBox.Items.Add("Pet's age: " + myPet.Age);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
