﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AreaClassLibrary
{
    public class circleArea
    {
        public static double circleFormula(double r)
        {
            //Declare variables
            double Area;

            //area calculation
            Area = Math.PI * r * Math.Pow(r, 2);

            //Return area
            return Area;
        }
    }
}
