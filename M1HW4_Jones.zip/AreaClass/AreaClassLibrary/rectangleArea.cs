﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AreaClassLibrary
{
    public class rectangleArea
    {
        public static double rectangleFormula(double w, double l)
        {
            //Declare variables
            double Area;

            //area calculation
            Area = w * l;

            //Return area
            return Area;
        }
    }
}
