﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AreaClassLibrary
{
    public class cylinderArea
    {
        public static double cylinderFormula(double r, double h)
        {
            //Declare variables
            double Area;

            //area calculation
            Area = Math.PI * Math.Pow(r, 2) * h;

            //Return area
            return Area;
        }
    }
}
