﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rectangleCalcButton = new System.Windows.Forms.Button();
            this.circleCalcButton = new System.Windows.Forms.Button();
            this.cylinderCalcButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.cylinderHeightTextBox = new System.Windows.Forms.TextBox();
            this.cylinderRadiusTextBox = new System.Windows.Forms.TextBox();
            this.rectangleHeightTextBox = new System.Windows.Forms.TextBox();
            this.rectangleWidthTextBox = new System.Windows.Forms.TextBox();
            this.circleRadiusTextBox = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.circleAreaTextBox = new System.Windows.Forms.TextBox();
            this.rectangleAreaTextBox = new System.Windows.Forms.TextBox();
            this.cylinderAreaTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // rectangleCalcButton
            // 
            this.rectangleCalcButton.Location = new System.Drawing.Point(83, 177);
            this.rectangleCalcButton.Name = "rectangleCalcButton";
            this.rectangleCalcButton.Size = new System.Drawing.Size(192, 23);
            this.rectangleCalcButton.TabIndex = 0;
            this.rectangleCalcButton.Text = "Calculate Rectangle Area";
            this.rectangleCalcButton.UseVisualStyleBackColor = true;
            this.rectangleCalcButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // circleCalcButton
            // 
            this.circleCalcButton.Location = new System.Drawing.Point(98, 63);
            this.circleCalcButton.Name = "circleCalcButton";
            this.circleCalcButton.Size = new System.Drawing.Size(177, 23);
            this.circleCalcButton.TabIndex = 1;
            this.circleCalcButton.Text = "Calculate Circle Area";
            this.circleCalcButton.UseVisualStyleBackColor = true;
            this.circleCalcButton.Click += new System.EventHandler(this.button2_Click);
            // 
            // cylinderCalcButton
            // 
            this.cylinderCalcButton.Location = new System.Drawing.Point(105, 305);
            this.cylinderCalcButton.Name = "cylinderCalcButton";
            this.cylinderCalcButton.Size = new System.Drawing.Size(181, 23);
            this.cylinderCalcButton.TabIndex = 2;
            this.cylinderCalcButton.Text = "Calculate Cylinder Area";
            this.cylinderCalcButton.UseVisualStyleBackColor = true;
            this.cylinderCalcButton.Click += new System.EventHandler(this.button3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 16);
            this.label1.TabIndex = 3;
            this.label1.Text = "Circle";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "Rectangle";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 217);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "Cylinder";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(33, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "Enter radius: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(31, 127);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 16);
            this.label5.TabIndex = 7;
            this.label5.Text = "Enter Width: ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(31, 152);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 16);
            this.label6.TabIndex = 8;
            this.label6.Text = "Enter Height: ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(35, 243);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 16);
            this.label7.TabIndex = 9;
            this.label7.Text = "Enter Height: ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(35, 277);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(90, 16);
            this.label8.TabIndex = 10;
            this.label8.Text = "Enter Radius: ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(86, 101);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(518, 16);
            this.label9.TabIndex = 11;
            this.label9.Text = "_________________________________________________________________________";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(74, 217);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(0, 16);
            this.label10.TabIndex = 12;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(59, 9);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(546, 16);
            this.label11.TabIndex = 13;
            this.label11.Text = "_____________________________________________________________________________";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(74, 217);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(532, 16);
            this.label12.TabIndex = 14;
            this.label12.Text = "___________________________________________________________________________";
            // 
            // cylinderHeightTextBox
            // 
            this.cylinderHeightTextBox.Location = new System.Drawing.Point(128, 243);
            this.cylinderHeightTextBox.Name = "cylinderHeightTextBox";
            this.cylinderHeightTextBox.Size = new System.Drawing.Size(134, 22);
            this.cylinderHeightTextBox.TabIndex = 15;
            // 
            // cylinderRadiusTextBox
            // 
            this.cylinderRadiusTextBox.Location = new System.Drawing.Point(128, 277);
            this.cylinderRadiusTextBox.Name = "cylinderRadiusTextBox";
            this.cylinderRadiusTextBox.Size = new System.Drawing.Size(134, 22);
            this.cylinderRadiusTextBox.TabIndex = 16;
            // 
            // rectangleHeightTextBox
            // 
            this.rectangleHeightTextBox.Location = new System.Drawing.Point(123, 149);
            this.rectangleHeightTextBox.Name = "rectangleHeightTextBox";
            this.rectangleHeightTextBox.Size = new System.Drawing.Size(119, 22);
            this.rectangleHeightTextBox.TabIndex = 17;
            // 
            // rectangleWidthTextBox
            // 
            this.rectangleWidthTextBox.Location = new System.Drawing.Point(110, 124);
            this.rectangleWidthTextBox.Name = "rectangleWidthTextBox";
            this.rectangleWidthTextBox.Size = new System.Drawing.Size(113, 22);
            this.rectangleWidthTextBox.TabIndex = 18;
            // 
            // circleRadiusTextBox
            // 
            this.circleRadiusTextBox.Location = new System.Drawing.Point(123, 35);
            this.circleRadiusTextBox.Name = "circleRadiusTextBox";
            this.circleRadiusTextBox.Size = new System.Drawing.Size(132, 22);
            this.circleRadiusTextBox.TabIndex = 19;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(307, 63);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(42, 16);
            this.label13.TabIndex = 20;
            this.label13.Text = "Area: ";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(307, 149);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(42, 16);
            this.label14.TabIndex = 21;
            this.label14.Text = "Area: ";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(307, 267);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(42, 16);
            this.label15.TabIndex = 22;
            this.label15.Text = "Area: ";
            // 
            // circleAreaTextBox
            // 
            this.circleAreaTextBox.Location = new System.Drawing.Point(355, 63);
            this.circleAreaTextBox.Name = "circleAreaTextBox";
            this.circleAreaTextBox.Size = new System.Drawing.Size(132, 22);
            this.circleAreaTextBox.TabIndex = 23;
            // 
            // rectangleAreaTextBox
            // 
            this.rectangleAreaTextBox.Location = new System.Drawing.Point(355, 146);
            this.rectangleAreaTextBox.Name = "rectangleAreaTextBox";
            this.rectangleAreaTextBox.Size = new System.Drawing.Size(132, 22);
            this.rectangleAreaTextBox.TabIndex = 24;
            // 
            // cylinderAreaTextBox
            // 
            this.cylinderAreaTextBox.Location = new System.Drawing.Point(355, 264);
            this.cylinderAreaTextBox.Name = "cylinderAreaTextBox";
            this.cylinderAreaTextBox.Size = new System.Drawing.Size(132, 22);
            this.cylinderAreaTextBox.TabIndex = 25;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 361);
            this.Controls.Add(this.cylinderAreaTextBox);
            this.Controls.Add(this.rectangleAreaTextBox);
            this.Controls.Add(this.circleAreaTextBox);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.circleRadiusTextBox);
            this.Controls.Add(this.rectangleWidthTextBox);
            this.Controls.Add(this.rectangleHeightTextBox);
            this.Controls.Add(this.cylinderRadiusTextBox);
            this.Controls.Add(this.cylinderHeightTextBox);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cylinderCalcButton);
            this.Controls.Add(this.circleCalcButton);
            this.Controls.Add(this.rectangleCalcButton);
            this.Name = "Form1";
            this.Text = "Area Calculators";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button rectangleCalcButton;
        private System.Windows.Forms.Button circleCalcButton;
        private System.Windows.Forms.Button cylinderCalcButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox cylinderHeightTextBox;
        private System.Windows.Forms.TextBox cylinderRadiusTextBox;
        private System.Windows.Forms.TextBox rectangleHeightTextBox;
        private System.Windows.Forms.TextBox rectangleWidthTextBox;
        private System.Windows.Forms.TextBox circleRadiusTextBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox circleAreaTextBox;
        private System.Windows.Forms.TextBox rectangleAreaTextBox;
        private System.Windows.Forms.TextBox cylinderAreaTextBox;
    }
}

