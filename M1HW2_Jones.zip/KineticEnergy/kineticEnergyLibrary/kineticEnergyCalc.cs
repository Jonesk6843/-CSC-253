﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kineticEnergyLibrary
{
    public class kineticEnergyCalc
    {
        public static double KineticEnergy(double mass, double velocity)
        {
            //Declare variables
            double kineticEnergy;

            //Kinetic energy formula
            kineticEnergy = 0.5 * mass * Math.Pow(velocity , 2);

            //Return Kinetic Energy
            return kineticEnergy;
        }
    }
}
