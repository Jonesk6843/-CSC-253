﻿/**
* 8/20/2022
* CSC 253
* Kent Jones Jr
* This program will allow the user to calculate an object's kinetic energy.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using kineticEnergyLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Declare user variables
                double userMass;
                double userVelocity;

                //convert user inputs from textboxes
                if (double.TryParse(massTextBox.Text, out userMass) && double.TryParse(velocityTextBox.Text, out userVelocity))
                    {
                        //Calculate user inputs and display total
                        double kineticEnergyTotal;
                        kineticEnergyTotal = kineticEnergyCalc.KineticEnergy(userMass, userVelocity);
                        kineticEnergyTextBox.Text = kineticEnergyTotal.ToString("");
                    }
                else
                {
                    MessageBox.Show("Please input valid numbers.", "Invalid Input");
                }  
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
