﻿/**
* 8/25/2022
* CSC 253
* Kent Jones
* This program will allow the user to increase and decrease the speeds of a virtual vehicle.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using carClassLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        //Create car object
        Car myCar = new Car();
        public Form1()
        {
            InitializeComponent();
        }

        private void accelerateButton_Click(object sender, EventArgs e)
        {
            myCar.incSpeed(5);
            speedLabel.Text = myCar.Speed.ToString();
        }

        private void brakeButton_Click(object sender, EventArgs e)
        {
            if (myCar.Speed <=0)
            {
                MessageBox.Show("You're stationary!");
            }
            else
            {
                myCar.decSpeed(5);
                speedLabel.Text = myCar.Speed.ToString();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //load car info
            carMakeLabel.Text = myCar.Make;
            carYearLabel.Text = myCar.Year;
            speedLabel.Text = myCar.Speed.ToString();
        }
    }
}
