﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace carClassLibrary
{
    public class Car
    {
        //fields
        private string _year;
        private string _make;
        private int _speed;

        //constructor
        public Car()
        {
            _year = "2016";
            _make = "Honda";
            _speed = 0;
        }

        public Car(string Make, string Year, int Speed)
        {
            _year = Year;
            _make = Make;
            _speed = Speed;
        }

        //properties
        public string Make
        {
            get { return _make; }
            set { _make = value; }
        }

        public string Year
        {
            get { return _year; }
            set { _year = value; }
        }

        public int Speed
        {
            get { return _speed; }
            set { _speed = value; }
        }

        public void incSpeed(int speedIncrease)
        {
            //speed limit range
            Speed += speedIncrease;
        }

        public void decSpeed(int speedDecrease)
        {
            //speed limit range
            Speed -= speedDecrease;
        }
    }
}
