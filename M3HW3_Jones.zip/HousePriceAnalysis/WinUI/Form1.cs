﻿/**
* 10/7/2022
* CSC 253
* Kent Jones Jr
* This program will allow the user to sort through a list of houses through space, number of baths, and number of bedrooms
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HousePriceAnalysisLibrary;
namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void searchButton_Click(object sender, EventArgs e)
        {
            //Declaring variables
            int minSpace;
            int maxSpace;
            int minBed;
            int maxBed;
            int minBath;
            int maxBath;


            //space range
            if (int.TryParse(minSpaceTextBox.Text, out minSpace) && int.TryParse(maxSpaceTextBox.Text, out maxSpace))
            {
                minSpace = int.Parse(minSpaceTextBox.Text);
                maxSpace = int.Parse(maxSpaceTextBox.Text);
                var spaceRange = houseList.houses.FindAll(space => minSpace <= maxSpace);
            }

            //bed range
            if (int.TryParse(minBedTextBox.Text, out minBed) && int.TryParse(maxBedTextBox.Text, out maxBed))
            {
                minBath = int.Parse(minBedTextBox.Text);
                maxBath = int.Parse(maxBedTextBox.Text);
                var bedRange = houseList.houses.FindAll(space => minBed <= maxBed);
            }

            //bath range
            if (int.TryParse(minBathTextBox.Text, out minBath) && int.TryParse(maxBathTextBox.Text, out maxBath))
            {
                minBath = int.Parse(minBathTextBox.Text);
                maxBath = int.Parse(minBathTextBox.Text);
                var bathRange = houseList.houses.FindAll(bath => minBath < maxBath);
            }

            //collect and display list
            foreach (var house in houseList.houses)
            {
                houseListBox.Items.Add(house);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //collect and display list
            foreach (var house in houseList.houses)
            {
                houseListBox.Items.Add(house);
            }
        }
    }
}
