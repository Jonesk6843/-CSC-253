﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.houseListBox = new System.Windows.Forms.ListBox();
            this.minSpaceTextBox = new System.Windows.Forms.TextBox();
            this.maxSpaceTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.maxBedTextBox = new System.Windows.Forms.TextBox();
            this.minBedTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.maxBathTextBox = new System.Windows.Forms.TextBox();
            this.minBathTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.searchButton = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // houseListBox
            // 
            this.houseListBox.FormattingEnabled = true;
            this.houseListBox.ItemHeight = 16;
            this.houseListBox.Location = new System.Drawing.Point(17, 16);
            this.houseListBox.Margin = new System.Windows.Forms.Padding(4);
            this.houseListBox.Name = "houseListBox";
            this.houseListBox.Size = new System.Drawing.Size(235, 292);
            this.houseListBox.TabIndex = 0;
            // 
            // minSpaceTextBox
            // 
            this.minSpaceTextBox.Location = new System.Drawing.Point(2, 24);
            this.minSpaceTextBox.Name = "minSpaceTextBox";
            this.minSpaceTextBox.Size = new System.Drawing.Size(100, 22);
            this.minSpaceTextBox.TabIndex = 4;
            // 
            // maxSpaceTextBox
            // 
            this.maxSpaceTextBox.Location = new System.Drawing.Point(138, 24);
            this.maxSpaceTextBox.Name = "maxSpaceTextBox";
            this.maxSpaceTextBox.Size = new System.Drawing.Size(100, 22);
            this.maxSpaceTextBox.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(108, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 16);
            this.label2.TabIndex = 11;
            this.label2.Text = "To";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.maxSpaceTextBox);
            this.groupBox2.Controls.Add(this.minSpaceTextBox);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(257, 55);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(243, 56);
            this.groupBox2.TabIndex = 16;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Space Range";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.maxBedTextBox);
            this.groupBox3.Controls.Add(this.minBedTextBox);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Location = new System.Drawing.Point(259, 126);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(243, 56);
            this.groupBox3.TabIndex = 17;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Bedroom Range";
            // 
            // maxBedTextBox
            // 
            this.maxBedTextBox.Location = new System.Drawing.Point(138, 24);
            this.maxBedTextBox.Name = "maxBedTextBox";
            this.maxBedTextBox.Size = new System.Drawing.Size(100, 22);
            this.maxBedTextBox.TabIndex = 5;
            // 
            // minBedTextBox
            // 
            this.minBedTextBox.Location = new System.Drawing.Point(2, 24);
            this.minBedTextBox.Name = "minBedTextBox";
            this.minBedTextBox.Size = new System.Drawing.Size(100, 22);
            this.minBedTextBox.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(108, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 16);
            this.label4.TabIndex = 11;
            this.label4.Text = "To";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.maxBathTextBox);
            this.groupBox4.Controls.Add(this.minBathTextBox);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Location = new System.Drawing.Point(259, 188);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(243, 56);
            this.groupBox4.TabIndex = 18;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Bathroom Range";
            // 
            // maxBathTextBox
            // 
            this.maxBathTextBox.Location = new System.Drawing.Point(138, 24);
            this.maxBathTextBox.Name = "maxBathTextBox";
            this.maxBathTextBox.Size = new System.Drawing.Size(100, 22);
            this.maxBathTextBox.TabIndex = 5;
            // 
            // minBathTextBox
            // 
            this.minBathTextBox.Location = new System.Drawing.Point(2, 24);
            this.minBathTextBox.Name = "minBathTextBox";
            this.minBathTextBox.Size = new System.Drawing.Size(100, 22);
            this.minBathTextBox.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(108, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(24, 16);
            this.label3.TabIndex = 11;
            this.label3.Text = "To";
            // 
            // searchButton
            // 
            this.searchButton.Location = new System.Drawing.Point(338, 255);
            this.searchButton.Name = "searchButton";
            this.searchButton.Size = new System.Drawing.Size(75, 23);
            this.searchButton.TabIndex = 19;
            this.searchButton.Text = "Search";
            this.searchButton.UseVisualStyleBackColor = true;
            this.searchButton.Click += new System.EventHandler(this.searchButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(515, 320);
            this.Controls.Add(this.searchButton);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.houseListBox);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "House Price Analysis";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox houseListBox;
        private System.Windows.Forms.TextBox minSpaceTextBox;
        private System.Windows.Forms.TextBox maxSpaceTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox maxBedTextBox;
        private System.Windows.Forms.TextBox minBedTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox maxBathTextBox;
        private System.Windows.Forms.TextBox minBathTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button searchButton;
    }
}

