﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace HousePriceAnalysisLibrary
{
    public class houseSearch
    {
        public static void loadHouse()
        {
            //Toeknizes through house_prices.csv file
            bool firstLine = true;
            using (StreamReader reader = File.OpenText(@"house_prices.csv"))
                while (!reader.EndOfStream)
                {
                    string[] tokens = reader.ReadLine().Split(',');
                    if (firstLine != true)
                    {
                        //Tokens in order (price, BedroomNum, bathroomNum, livingSpacec)
                        houseList.houses.Add(new House(tokens[0], tokens[1], tokens[2], tokens[3]));
                    }
                    else
                    {
                        firstLine = false;
                    }
                }
        }
    }
}
