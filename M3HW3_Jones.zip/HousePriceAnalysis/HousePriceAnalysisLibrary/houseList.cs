﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HousePriceAnalysisLibrary
{
    public static class houseList
    {
        public static List<House> houses = new List<House>();
    }
}
