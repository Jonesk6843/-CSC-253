﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace HousePriceAnalysisLibrary
{
    public class House
    {
        //Fields
        private string _price;
        private string _bedroomNum;
        private string _bathroomNum;
        private string _livingSpace;

        //constructor
        public House()
        {
            _price = "";
            _bedroomNum = "";
            _bathroomNum = "";
            _livingSpace = "";
        }

        public House(string price, string bedroomNum, string bathroomNum, string livingSpace)
        {
            _price = price;
            _bedroomNum = bedroomNum;
            _bathroomNum = bathroomNum;
            _livingSpace = livingSpace;
        }

        //properties
        public string price { get; set; }
        public string bedroomNum { get; set; }
        public string bathroomNum { get; set; }
        public string livingSpace { get; set; }
    }
}
