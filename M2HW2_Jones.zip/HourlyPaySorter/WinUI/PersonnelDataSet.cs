﻿namespace WinUI
{


    partial class PersonnelDataSet
    {
    }
}

namespace WinUI.PersonnelDataSetTableAdapters {
    
    
    public partial class EmployeeTableAdapter {
    }
}
