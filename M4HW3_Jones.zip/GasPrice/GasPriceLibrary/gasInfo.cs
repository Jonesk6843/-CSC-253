﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace GasPriceLibrary
{
    public class gasInfo
    {
        private int _month;
        private int _day;
        private int _year;
        private double _price;

        //constructor
        public gasInfo()
        {
            _month = 0;
            _day = 0;
            _year = 0;
            _price = 0.0;
        }

        public gasInfo(int month, int day, int year, double price)
        {
            _month = month;
            _day = day;
            _year = year;
            _price = price;
        }

        //properties
        public int Month
        {
            get { return _month; }
            set { _month = value; }
        }

        public int Day
        {
            get { return _day; }
            set { _day = value; }
        }
        public int Year
        {
            get { return _year; }
            set { _year = value; }
        }
        public double Price
        {
            get { return _price; }
            set { _price = value; }
        }
    }
}
