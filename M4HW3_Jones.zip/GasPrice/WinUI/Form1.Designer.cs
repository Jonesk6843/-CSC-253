﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gasPriceListBox = new System.Windows.Forms.ListBox();
            this.averagePerYearButton = new System.Windows.Forms.Button();
            this.averagePerMonthButton = new System.Windows.Forms.Button();
            this.printHighLowButton = new System.Windows.Forms.Button();
            this.printLowHighButton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.highLowButton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // gasPriceListBox
            // 
            this.gasPriceListBox.FormattingEnabled = true;
            this.gasPriceListBox.ItemHeight = 16;
            this.gasPriceListBox.Location = new System.Drawing.Point(16, 15);
            this.gasPriceListBox.Margin = new System.Windows.Forms.Padding(4);
            this.gasPriceListBox.Name = "gasPriceListBox";
            this.gasPriceListBox.Size = new System.Drawing.Size(323, 356);
            this.gasPriceListBox.TabIndex = 0;
            // 
            // averagePerYearButton
            // 
            this.averagePerYearButton.Location = new System.Drawing.Point(104, 23);
            this.averagePerYearButton.Margin = new System.Windows.Forms.Padding(4);
            this.averagePerYearButton.Name = "averagePerYearButton";
            this.averagePerYearButton.Size = new System.Drawing.Size(100, 28);
            this.averagePerYearButton.TabIndex = 1;
            this.averagePerYearButton.Text = "Per Year";
            this.averagePerYearButton.UseVisualStyleBackColor = true;
            this.averagePerYearButton.Click += new System.EventHandler(this.averagePerYearButton_Click);
            // 
            // averagePerMonthButton
            // 
            this.averagePerMonthButton.Location = new System.Drawing.Point(0, 23);
            this.averagePerMonthButton.Margin = new System.Windows.Forms.Padding(4);
            this.averagePerMonthButton.Name = "averagePerMonthButton";
            this.averagePerMonthButton.Size = new System.Drawing.Size(100, 28);
            this.averagePerMonthButton.TabIndex = 2;
            this.averagePerMonthButton.Text = "Per month";
            this.averagePerMonthButton.UseVisualStyleBackColor = true;
            this.averagePerMonthButton.Click += new System.EventHandler(this.averagePerMonthButton_Click);
            // 
            // printHighLowButton
            // 
            this.printHighLowButton.Location = new System.Drawing.Point(8, 23);
            this.printHighLowButton.Margin = new System.Windows.Forms.Padding(4);
            this.printHighLowButton.Name = "printHighLowButton";
            this.printHighLowButton.Size = new System.Drawing.Size(100, 28);
            this.printHighLowButton.TabIndex = 4;
            this.printHighLowButton.Text = "High to Low";
            this.printHighLowButton.UseVisualStyleBackColor = true;
            this.printHighLowButton.Click += new System.EventHandler(this.printHighLowButton_Click);
            // 
            // printLowHighButton
            // 
            this.printLowHighButton.Location = new System.Drawing.Point(8, 70);
            this.printLowHighButton.Margin = new System.Windows.Forms.Padding(4);
            this.printLowHighButton.Name = "printLowHighButton";
            this.printLowHighButton.Size = new System.Drawing.Size(100, 28);
            this.printLowHighButton.TabIndex = 5;
            this.printLowHighButton.Text = "Low to High";
            this.printLowHighButton.UseVisualStyleBackColor = true;
            this.printLowHighButton.Click += new System.EventHandler(this.printLowHighButton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.averagePerYearButton);
            this.groupBox1.Controls.Add(this.averagePerMonthButton);
            this.groupBox1.Location = new System.Drawing.Point(346, 57);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(204, 60);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Average Price Per-";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.printLowHighButton);
            this.groupBox2.Controls.Add(this.printHighLowButton);
            this.groupBox2.Location = new System.Drawing.Point(382, 183);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(117, 108);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Print";
            // 
            // highLowButton
            // 
            this.highLowButton.Location = new System.Drawing.Point(370, 135);
            this.highLowButton.Name = "highLowButton";
            this.highLowButton.Size = new System.Drawing.Size(141, 23);
            this.highLowButton.TabIndex = 8;
            this.highLowButton.Text = "High/Low Per Year";
            this.highLowButton.UseVisualStyleBackColor = true;
            this.highLowButton.Click += new System.EventHandler(this.highLowButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(563, 382);
            this.Controls.Add(this.highLowButton);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.gasPriceListBox);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Gas Prices";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox gasPriceListBox;
        private System.Windows.Forms.Button averagePerYearButton;
        private System.Windows.Forms.Button averagePerMonthButton;
        private System.Windows.Forms.Button printHighLowButton;
        private System.Windows.Forms.Button printLowHighButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button highLowButton;
    }
}

