﻿/**
* 10/26/2022
* CSC 253
* Kent Jones
* This program will allow the user to manipulate a given list of gas prices.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GasPriceLibrary;
using System.IO;
using System.Diagnostics;
using static System.Net.Mime.MediaTypeNames;

namespace WinUI
{
    public partial class Form1 : Form
    {
        //Declaring Variables
        StreamWriter outputFile;

        public Form1()
        {
            InitializeComponent();
        }
        //Declaring global list
        public static List<gasInfo> gasPrice = new List<gasInfo>();
        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                //Tokenizing through list by "\n" 
                string[] gasInfo = File.ReadAllText(@"GasPrices.txt").Split('\n');

                //Setting each part of gasPrice to variable (month, day, year, price)
                foreach (string info in gasInfo)
                {
                    //Splitting variables
                    string[] priceSplit = info.Split(':');
                    string[] dateSplit = priceSplit[0].Split('-');

                    //Declaring variables
                    int month = Convert.ToInt32(dateSplit[0]);
                    int day = Convert.ToInt32(dateSplit[1]);
                    int year = Convert.ToInt32(dateSplit[2]);
                    double price = Convert.ToDouble(priceSplit[1]);
                
                    //Adding information to global list
                    gasPrice.Add(new gasInfo(month, day, year, price));
                }

                //Populating gasPriceListBox
                for (int i = 0; i < gasInfo.Length; i++)
                {
                    gasPriceListBox.Items.Add(gasInfo[i]);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }
        private void averagePerMonthButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Getting average per month
                for (int i = 02; i <= 12; i++)
                {
                    // Find and calculate all records mathing minimum and maximum month index
                    List<gasInfo> month = gasPrice.FindAll(a => a.Month == i);
                    var averagePerMonth = month.Average(a => a.Price);

                    //Display matches
                    MessageBox.Show($"The gas price for month ({i}) is {averagePerMonth}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void averagePerYearButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Gets the average price for each year in the list
                for (int i = 1993; i <= 2013; i++)
                {
                    //Find and calculate all records mathing minimum and maximum year index
                    List<gasInfo> year = gasPrice.FindAll(a => a.Year == i);
                    var averagePerYear = year.Average(a => a.Price);

                    //Display matches
                    MessageBox.Show($"The gas price for the Year of {i} is {averagePerYear}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
           
        }
        private void highLowButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Gets the average price for each year in the list
                for (int i = 1993; i <= 2013; i++)
                {
                    //Find and all records mathing minimum and maximum year index
                    List<gasInfo> year = gasPrice.FindAll(a => a.Year == i);

                    //Find max and min dates
                    var max = year.Max(a => a.Price);
                    var maxDate = gasPrice.Find(a => a.Price == max);
                    var min = year.Min(a => a.Price);
                    var minDate = gasPrice.Find(a => a.Price == min);

                    //access max and min prices
                    var maxPrice = year.Max(a => a.Price);
                    var minPrice = year.Min(a => a.Price);

                    //Creating date strings
                    string minDateString = minDate.Month.ToString() + "/" + minDate.Day.ToString() + "/" + minDate.Year.ToString();
                    string maxDateString = maxDate.Month.ToString() + "/" + maxDate.Day.ToString() + "/" + maxDate.Year.ToString();

                    //Display message
                    MessageBox.Show($"Year: {i}" + "\n" + $"The highest price was {maxPrice} on {maxDateString}." +
                        "\n" + $"The lowest price was on {minPrice} on {minDateString}.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void printHighLowButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Creating outputfile
                outputFile = File.CreateText("GasPrices(HighToLow).txt");

                //Sort through list
                var highToLow = gasPrice.OrderByDescending(x => x.Price).ToList();

                //Writing to file for each sort
                foreach (gasInfo sort in highToLow)
                {
                    outputFile.WriteLine($"{sort.Month}/{sort.Day}/{sort.Year} Price: {sort.Price}");
                }
                MessageBox.Show("File Has Printed!");
                outputFile.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void printLowHighButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Creating outputfile
                outputFile = File.CreateText("GasPrices(LowToHigh).txt");

                //Sort through list and sort
                var lowToHigh = gasPrice.OrderBy(x => x.Price).ToList();

                //Writing to file for each sort
                foreach (gasInfo sort in lowToHigh)
                {
                    outputFile.WriteLine($"{sort.Month}/{sort.Day}/{sort.Year} Price: {sort.Price}");
                }
                MessageBox.Show("File Has Printed!");
                outputFile.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        
    }
}
