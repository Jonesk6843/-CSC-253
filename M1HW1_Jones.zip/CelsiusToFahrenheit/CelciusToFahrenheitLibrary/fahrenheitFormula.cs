﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CelciusToFahrenheitLibrary
{
    public class fahrenheitFormula
    {
        public static double fahrenheitCalc(double C)
        {
            //Declare variables
            double fahrenheit;

            //celcius to fahrenheit calculation
            fahrenheit = (C * 9)/5 + 32;

            //Return Fahrenheit
            return fahrenheit;
        }

    }
}
