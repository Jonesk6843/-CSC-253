﻿/**
* 8/20/2022
* CSC 253
* Kent Jones Jr
* This program will display to the user Celcuis values 0 to 20 converted to Fahrenehit.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using CelciusToFahrenheitLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Declare Variables
            double Celcius = 0;
           
            try
            {
                //Loop Celcius amount up to 20
                while (Celcius <= 20)
                {
                    double fahrenheit;
                    fahrenheit = fahrenheitFormula.fahrenheitCalc(Celcius);
                    tempListBox.Items.Add(Celcius + "C = " + fahrenheit + "F");
                    Celcius++;
                    fahrenheit = 0.0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
