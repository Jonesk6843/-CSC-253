﻿/**
* 3/5/22
* CSC 153
* Kent Jones Jr
* This program will allow the user to calculate an item's retail Price
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RetailPriceCalculatorLibrary;
namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CalculateButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Declare Variables
                double userWholesale;
                double userMarkup;

                //Display Calculations
                if (double.TryParse(itemCostTextBox.Text, out userWholesale) && double.TryParse(markupTextBox.Text, out userMarkup))
                {
                    double retailTotal;
                    retailTotal = RetailCalculations.CalculateRetail(userWholesale, userMarkup);
                    retailPriceTextBox.Text = retailTotal.ToString("C");
                }
                else
                {
                    //Display error message if strings are inputed.
                    MessageBox.Show("Please enter integers only!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
