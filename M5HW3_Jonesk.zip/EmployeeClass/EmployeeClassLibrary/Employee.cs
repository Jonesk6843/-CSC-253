﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeClassLibrary
{
    public class Employee
    {
        //Fields
        public string _Name;
        public int _IdNumber;
        public string _Department;
        public string _Position;

        //constructor
        public Employee()
        {
            _Name = "";
            _IdNumber = 0;
            _Department = "";
            _Position = "";
        }

        public Employee(string employeeName, int employeeIdNumber, string department, string position)
        {
            _Name = employeeName;
            _IdNumber = employeeIdNumber;
            _Department = department;
            _Position = position;
        }
        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }
        public int IdNumber
        {
            get { return _IdNumber; }
            set { _IdNumber = value; }
        }
        public string Department
        {
            get { return _Department; }
            set { _Department = value; }
        }
        public string Position
        {
            get { return _Position; }
            set { _Position = value; }
        }
    }
}
